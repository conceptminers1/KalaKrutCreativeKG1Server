
import React, { useState, startTransition } from 'react';
import { 
  LayoutGrid, Users, Calendar, Vote, Settings, LogOut, Menu, X, ShoppingBag, Briefcase, 
  BarChart3, Contact2, Bot, MessageSquare, UploadCloud, Network, GitMerge, LifeBuoy, CreditCard, Coins, FileText, FileSignature, AlertTriangle, ToggleLeft, ToggleRight, ShieldCheck, Wallet, Bell, Search
} from 'lucide-react';
import { UserRole, IArtistProfile } from '../types';
import { useWallet } from '../contexts/WalletContext';
import { useData } from '../contexts/DataContext';
import SupportWidget from '../components/SupportWidget';
import { useToast } from '../contexts/ToastContext';

interface LayoutProps {
  children: React.ReactNode;
  userRole: UserRole;
  currentUser?: IArtistProfile;
  onNavigate: (view: string) => void;
  onLogout: () => void;
  onSearch: (query: string) => void;
  currentView: string;
}

const Layout: React.FC<LayoutProps> = ({ 
  children, 
  userRole, 
  currentUser,
  onNavigate, 
  onLogout,
  onSearch,
  currentView 
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { isDemoMode, demoModeAvailable, setDemoModeAvailable } = useData();
  const { notify } = useToast();
  const { isConnected, connect, disconnect, walletAddress, balances } = useWallet();

  const handleSettingsClick = () => {
    setIsSettingsOpen(true);
  };
  
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  const handleSearchSubmit = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      onSearch(searchQuery);
    }
  };

  const handleToggleDemoAvailability = () => {
    if (userRole !== UserRole.ADMIN) {
      notify("You do not have permission to change this setting.", "error");
      return;
    }
    if (isDemoMode) {
       notify("System settings are read-only in Demo Mode. Login to Live Mode to make changes.", "warning");
       return;
    }
    const newState = !demoModeAvailable;
    setDemoModeAvailable(newState);
    notify(`Demo Mode has been ${newState ? 'ENABLED' : 'DISABLED'} for all users.`, "success");
  };

  const NavItem = ({ id, icon: Icon, label, disabled = false }: { id: string, icon: any, label: string, disabled?: boolean }) => (
    <button
      onClick={() => {
        if (disabled) return;
        startTransition(() => {
          onNavigate(id);
        });
        setIsMobileMenuOpen(false);
      }}
      disabled={disabled}
      className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg transition-all duration-200 ${
        currentView === id 
          ? 'bg-kala-secondary/10 text-kala-secondary border-r-2 border-kala-secondary' 
          : 'text-slate-400 hover:bg-kala-800 hover:text-white'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      <Icon className="w-5 h-5" />
      <span className="font-medium">{label}</span>
    </button>
  );

  const mainNavItems = [
    { id: 'dashboard', icon: LayoutGrid, label: 'Dashboard' },
    { id: 'marketplace', icon: ShoppingBag, label: 'Marketplace' },
    { id: 'services', icon: Briefcase, label: 'Services Hub' },
    { id: 'booking', icon: Calendar, label: 'Proposals & Bookings' },
    { id: 'studio', icon: UploadCloud, label: 'Creative Studio' },
  ];

  const communityNavItems = [
    { id: 'roster', icon: Contact2, label: 'Roster / Members' },
    { id: 'forum', icon: MessageSquare, label: 'Forum' },
    { id: 'my_circle', icon: Users, label: 'My Circle' },
    { id: 'membership', icon: CreditCard, label: 'Membership & Plans' },
  ];

  const systemNavItems = [
    { id: 'sitemap', icon: Network, label: 'Site Map' },
    { id: 'whitepaper', icon: FileText, label: 'Whitepaper & Docs' },
  ];

  const adminNavItems = [
    { id: 'governance', icon: Vote, label: 'DAO Governance', roles: [UserRole.ADMIN, UserRole.DAO_GOVERNOR, UserRole.DAO_MEMBER] },
    { id: 'contracts', icon: FileSignature, label: 'Contracts & Agreements', roles: [UserRole.ADMIN, UserRole.DAO_GOVERNOR, UserRole.DAO_MEMBER] },
    { id: 'treasury', icon: Coins, label: 'Treasury', roles: [UserRole.ADMIN, UserRole.DAO_GOVERNOR] },
    { id: 'hrd', icon: Briefcase, label: 'HRD & Team', roles: [UserRole.ADMIN] },
    { id: 'analytics', icon: BarChart3, label: 'Analytics', roles: [UserRole.ADMIN] },
    { id: 'admin_support', icon: LifeBuoy, label: 'Support Center', roles: [UserRole.ADMIN] },
    { id: 'leads', icon: Bot, label: 'Leads & AI', roles: [UserRole.ADMIN] },
    { id: 'system_docs', icon: GitMerge, label: 'Architecture & ERD', roles: [UserRole.ADMIN] },
    { id: 'admin_email_templates', icon: FileText, label: 'Email Templates', roles: [UserRole.ADMIN] },
  ];

  const visibleAdminItems = adminNavItems.filter(item => item.roles.includes(userRole));

  return (
    <div className="min-h-screen bg-kala-900 flex text-slate-200 font-sans selection:bg-kala-secondary selection:text-kala-900">
      
      {/* --- Sidebar --- */}
      <aside className={`
        fixed lg:static top-0 left-0 z-40 h-full w-64 bg-kala-900 border-r border-kala-800 transform transition-transform duration-300 ease-in-out
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="p-6 border-b border-kala-800">
           <div className="font-bold text-2xl tracking-tighter text-white">
            Kala<span className="text-kala-secondary">Krut</span>
            <span className="text-[10px] ml-1 bg-kala-700 text-kala-300 px-1.5 py-0.5 rounded">v3.0</span>
          </div>
          <p className="text-xs text-kala-500 mt-1">Creative Portal</p>
        </div>

        <div className="p-4 space-y-1 overflow-y-auto h-[calc(100vh-80px)] custom-scrollbar">
          <div className="text-xs font-bold text-kala-600 uppercase px-4 py-2">Main</div>
          {mainNavItems.map(item => <NavItem key={item.id} {...item} />)}

          <div className="text-xs font-bold text-kala-600 uppercase px-4 py-2 mt-4">Community</div>
          {communityNavItems.map(item => <NavItem key={item.id} {...item} />)}

          <div className="text-xs font-bold text-kala-600 uppercase px-4 py-2 mt-4">System</div>
          {systemNavItems.map(item => <NavItem key={item.id} {...item} />)}
          
          
           {visibleAdminItems.length > 0 && (
             <>
               <div className="text-xs font-bold text-kala-600 uppercase px-4 py-2 mt-4">Admin / DAO</div>
               {visibleAdminItems.map(item => <NavItem key={item.id} {...item} />)}
             </>
          )}
        </div>
      </aside>

      {/* --- Main Content --- */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        
        {/* --- Header --- */}
        <header className="bg-kala-900/80 backdrop-blur-sm border-b border-kala-800 sticky top-0 z-30">
          <div className="flex items-center justify-between p-4">
            
            {/* Mobile Menu & Search */}
            <div className="flex items-center gap-4">
              <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="lg:hidden text-kala-300">
                {isMobileMenuOpen ? <X /> : <Menu />}
              </button>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-kala-500" />
                <input 
                  type="text"
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={handleSearchChange}
                  onKeyDown={handleSearchSubmit}
                  className="bg-kala-800 border border-kala-700 rounded-lg pl-9 pr-4 py-2 text-sm w-full md:w-64 focus:outline-none focus:border-kala-secondary" 
                />
              </div>
            </div>

            {/* Header Actions */}
            {currentUser && 
            <div className="flex items-center gap-4">
              {isDemoMode && (
                <div className="bg-yellow-500/20 text-yellow-300 text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-2 border border-yellow-500/30">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Demo Mode</span>
                </div>
              )}
              
              {!isConnected ? (
                 <button onClick={() => connect()} className="flex items-center gap-2 px-4 py-2 text-sm font-bold bg-kala-800 hover:bg-kala-700 border border-kala-700 rounded-lg transition-colors">
                    <Wallet className="w-4 h-4" /> Connect Wallet
                 </button>
              ) : (
                <div className="flex items-center gap-2 bg-kala-800 border border-kala-700 px-3 py-1.5 rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                  <span className="text-xs font-mono text-kala-400">{`${walletAddress?.substring(0, 6)}...${walletAddress?.substring(walletAddress.length - 4)}`}</span>
                </div>
              )}
              
              <button className="p-2 rounded-lg bg-kala-800 hover:bg-kala-700 border border-kala-700">
                <Bell className="w-5 h-5 text-kala-400" />
              </button>
              
              <div className="relative group">
                <button 
                  onClick={() => onNavigate('profile')}
                  className="w-10 h-10 rounded-full bg-kala-700 border-2 border-kala-600 group-hover:border-kala-secondary transition-colors"
                >
                  <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full rounded-full object-cover" />
                </button>
                <div className="absolute top-full right-0 mt-2 w-48 bg-kala-800 border border-kala-700 rounded-xl shadow-lg p-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none group-hover:pointer-events-auto">
                    <div className="px-3 py-2 border-b border-kala-700">
                       <p className="text-sm font-bold text-white truncate">{currentUser.name}</p>
                       <p className="text-xs text-kala-500 truncate">{currentUser.role}</p>
                    </div>
                    <div className="py-1">
                      <button onClick={() => onNavigate('profile')} className="w-full text-left flex items-center gap-2 px-3 py-2 text-sm rounded-md text-kala-300 hover:bg-kala-700/50 hover:text-white">
                         <Users className="w-4 h-4" /> My Profile
                      </button>
                      <button onClick={handleSettingsClick} className="w-full text-left flex items-center gap-2 px-3 py-2 text-sm rounded-md text-kala-300 hover:bg-kala-700/50 hover:text-white">
                         <Settings className="w-4 h-4" /> Settings
                      </button>
                    </div>
                    <div className="py-1 border-t border-kala-700">
                       <button onClick={onLogout} className="w-full text-left flex items-center gap-2 px-3 py-2 text-sm rounded-md text-red-400 hover:bg-red-500/20 hover:text-red-300">
                          <LogOut className="w-4 h-4" /> Logout
                       </button>
                    </div>
                </div>
              </div>

            </div>
            }
          </div>
        </header>

        {/* Main content area */}
        <main className="flex-1 overflow-y-auto bg-kala-900">
          <div className="p-4 lg:p-8 max-w-7xl mx-auto">
            {children}
          </div>
          <SupportWidget />
        </main>
      </div>

      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {isSettingsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
           <div className="bg-kala-900 border border-kala-700 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
              <div className="p-4 border-b border-kala-800 flex justify-between items-center bg-kala-800/50">
                 <h3 className="text-white font-bold flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-kala-secondary" /> System Configuration
                 </h3>
                 <button onClick={() => setIsSettingsOpen(false)} className="text-kala-500 hover:text-white">
                    <X className="w-5 h-5" />
                 </button>
              </div>
              <div className="p-6 space-y-6">
                 <div className={`bg-kala-800 p-4 rounded-xl border border-kala-700 flex items-center justify-between ${!isUserAdmin || isDemoMode ? 'opacity-50 cursor-not-allowed' : ''}`}>
                    <div>
                       <h4 className="text-white font-bold text-sm flex items-center gap-2">
                          Public Demo Mode
                          {isDemoMode && <span className="text-[10px] bg-yellow-500/20 text-yellow-400 px-1.5 py-0.5 rounded border border-yellow-500/30">READ ONLY</span>}
                       </h4>
                       <p className="text-xs text-kala-400 mt-1 max-w-[200px]">
                          Allow visitors to access the platform with mock data. Disable for production launch.
                       </p>
                    </div>
                    <button 
                      onClick={handleToggleDemoAvailability}
                      disabled={!isUserAdmin || isDemoMode}
                      className={`relative w-12 h-6 rounded-full transition-colors ${demoModeAvailable ? 'bg-green-500' : 'bg-kala-700'} ${!isUserAdmin || isDemoMode ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                    >
                       <div className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${demoModeAvailable ? 'translate-x-6' : 'translate-x-0'}`}></div>
                    </button>
                 </div>
                 
                 {(!isUserAdmin || isDemoMode) && (
                    <div className="bg-yellow-500/10 border border-yellow-500/20 p-3 rounded-lg flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0 mt-0.5" />
                        <p className="text-xs text-yellow-200">
                           {isDemoMode ? 'You are currently in Demo Mode. Global system settings can only be changed by a verified Admin in Live Mode.' : 'You do not have permission to change these settings.'}
                        </p>
                    </div>
                 )}
                 
                 <div className="text-xs text-center text-kala-500">
                    Changes take effect immediately on the Login Screen.
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Layout;
