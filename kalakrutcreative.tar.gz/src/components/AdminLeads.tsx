
import React, { useState } from 'react';
import { Bot, RefreshCw, FileSpreadsheet, Send, Search, BrainCircuit, UserPlus, Dna, Trash2, UserCheck } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { knowledgeGraph, searchMusicBrainz } from '../services/knowledgeGraphService';
import { useData } from '../contexts/DataContext';
import { LeadQuery, User, UserRole } from '../types';

interface Lead {
  leadId: string;
  targetId: string; 
  targetName: string;
  targetType: string;
  reason: string;
  status: 'New' | 'Contacted' | 'Closed';
  confidenceScore: number;
  assignedUser?: string; // ID of the user this lead is assigned to
}

interface MusicBrainzArtist {
  id: string;
  name: string;
  country: string;
  score: number;
}

const AdminLeads: React.FC = () => {
  const { notify } = useToast();
  const { users, updateUser } = useData();
  const [isSyncing, setIsSyncing] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [query, setQuery] = useState('Find artists with releases but no upcoming events.');
  const [mbQuery, setMbQuery] = useState('');
  const [mbResults, setMbResults] = useState<MusicBrainzArtist[]>([]);

  const handleRunQuery = () => {
      setIsSyncing(true);
      const foundLeads = knowledgeGraph.findLeads(query);
      
      setTimeout(() => {
        setLeads(foundLeads as Lead[]);
        setIsSyncing(false);
        notify(`LeadGeniusAI found ${foundLeads.length} new leads.`, "success");
      }, 1500);
  };

  const handleSearchMusicBrainz = async () => {
    if (!mbQuery.trim()) return;
    setIsSearching(true);
    try {
      const results = await searchMusicBrainz(mbQuery);
      setMbResults(results);
      notify(`Found ${results.length} artists on MusicBrainz.`, "info");
    } catch (error) {
      console.error(error);
      notify("Failed to fetch data from MusicBrainz.", "error");
    }
    setIsSearching(false);
  };

  const handleCreateLeadFromMB = (artist: MusicBrainzArtist) => {
    const leadId = `lead-mb-${artist.id}`;
    if (leads.some(l => l.leadId === leadId)) {
        notify(`${artist.name} is already a lead.`, "warning");
        return;
    }

    const matchingUser = users.find(u => u.name.toLowerCase() === artist.name.toLowerCase());

    const newLead: Lead = {
      leadId,
      targetId: `mbid-${artist.id}`,
      targetName: artist.name,
      targetType: 'Artist',
      reason: `Matched from MusicBrainz. Country: ${artist.country}`,
      status: 'New',
      confidenceScore: artist.score / 100,
      assignedUser: matchingUser?.id
    };

    setLeads(prev => [newLead, ...prev]);
    
    if (matchingUser) {
        const userLead: LeadQuery = {
            id: leadId,
            date: new Date().toLocaleDateString(),
            query: `Admin-generated lead from MusicBrainz: ${artist.name}`,
            responseSummary: `A new lead was created for you by an admin based on a match from the MusicBrainz knowledge graph. Confidence: ${newLead.confidenceScore.toFixed(2)}`,
            method: 'Auto-Sync',
            isPaidService: true
        };
        
        const updatedUser = { 
            ...matchingUser, 
            leadQueries: [userLead, ...(matchingUser.leadQueries || [])] 
        };
        updateUser(matchingUser.id, updatedUser);
        notify(`New lead created and assigned to user: ${matchingUser.name}.`, "success");
    } else {
        knowledgeGraph.addNode('leads', newLead.leadId, newLead);
        notify(`New unassigned lead created for ${artist.name}.`, "success");
    }
  };

  const handleDeleteLead = (leadId: string) => {
    const leadToDelete = leads.find(l => l.leadId === leadId);
    if (!leadToDelete) return;

    // If lead was assigned to a user, remove it from their profile
    if (leadToDelete.assignedUser) {
        const user = users.find(u => u.id === leadToDelete.assignedUser);
        if (user) {
            const updatedUser = { 
                ...user, 
                leadQueries: user.leadQueries?.filter(lq => lq.id !== leadId) || []
            };
            updateUser(user.id, updatedUser);
        }
    }

    setLeads(prev => prev.filter(l => l.leadId !== leadId));
    notify(`Lead ${leadToDelete.targetName} deleted.`, "info");
  };


  return (
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Bot className="text-indigo-400" /> Lead Management
            </h2>
            <p className="text-kala-400 text-sm">Automated & manual lead generation via LeadGeniusAI, powered by the Knowledge Graph.</p>
          </div>
          <div className="flex gap-2">
             <a 
               href="https://docs.google.com/spreadsheets/d/1_JDe6kZ9SiEMLueA8isrVMKLogYbSwpO3utV8_BrlQg/edit?usp=drivesdk"
               target="_blank"
               rel="noreferrer"
               className="bg-kala-800 hover:bg-kala-700 text-white font-bold px-4 py-2 rounded-lg flex items-center gap-2 transition-colors border border-kala-700"
             >
               <FileSpreadsheet className="w-4 h-4" /> Open Leads Sheet
             </a>
          </div>
        </div>

        {/* AI Engines Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Query Engine */}
          <div className="bg-kala-900/50 border border-kala-800 rounded-xl p-6 flex flex-col">
            <div className="flex-grow">
              <label className="block text-sm text-kala-300 font-bold mb-2 flex items-center gap-2"><Dna className="w-4 h-4 text-indigo-400"/>LeadGeniusAI Query Prompt</label>
              <textarea 
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="w-full bg-kala-800 border border-kala-700 rounded-lg px-4 py-2 text-white outline-none focus:border-indigo-500 text-sm" 
                  rows={2}
                  placeholder="e.g., Find venues that haven't hosted a show in 3 months..."
              />
              <p className="text-xs text-kala-500 mt-2">
                * Triggers engine to scan the internal Knowledge Graph for opportunities.
              </p>
            </div>
            <button 
                onClick={handleRunQuery}
                disabled={isSyncing}
                className="mt-4 w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-6 py-3 rounded-lg flex items-center justify-center gap-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
                {isSyncing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />} 
                {isSyncing ? 'Analyzing Internal Graph...' : 'Run Internal Query'}
            </button>
          </div>

          {/* MusicBrainz Search */}
          <div className="bg-kala-900/50 border border-kala-800 rounded-xl p-6 flex flex-col">
            <div className="flex-grow">
              <label className="block text-sm text-kala-300 font-bold mb-2 flex items-center gap-2"><BrainCircuit className="w-4 h-4 text-cyan-400"/>MusicBrainz Artist Search</label>
              <input 
                  type="text"
                  value={mbQuery}
                  onChange={(e) => setMbQuery(e.target.value)}
                  className="w-full bg-kala-800 border border-kala-700 rounded-lg px-4 py-2 text-white outline-none focus:border-cyan-500 text-sm"
                  placeholder="e.g., Radiohead, Daft Punk, etc."
                  onKeyDown={(e) => e.key === 'Enter' && handleSearchMusicBrainz()}
              />
              <p className="text-xs text-kala-500 mt-2">
                * Search the external MusicBrainz knowledge graph for new artists.
              </p>
            </div>
            <button 
                onClick={handleSearchMusicBrainz}
                disabled={isSearching}
                className="mt-4 w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold px-6 py-3 rounded-lg flex items-center justify-center gap-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
                {isSearching ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />} 
                {isSearching ? 'Searching MusicBrainz...' : 'Search Artists'}
            </button>
          </div>
        </div>

        {/* MusicBrainz Results */}
        {mbResults.length > 0 && (
           <div className="bg-kala-800/40 border border-kala-700/80 rounded-xl">
             <div className="p-4 border-b border-kala-700">
                <h3 className="font-bold text-white">MusicBrainz Search Results</h3>
             </div>
             <div className="overflow-x-auto">
                 <table className="w-full text-sm text-left">
                    <thead className="text-xs text-kala-400 uppercase bg-kala-800/60">
                       <tr>
                          <th className="px-6 py-3">Artist</th>
                          <th className="px-6 py-3">Country</th>
                          <th className="px-6 py-3 text-center">Match Score</th>
                          <th className="px-6 py-3 text-right">Action</th>
                       </tr>
                    </thead>
                    <tbody>
                       {mbResults.map(artist => (
                          <tr key={artist.id} className="border-b border-kala-800 hover:bg-kala-800/50">
                             <td className="px-6 py-4 font-medium text-white">{artist.name}</td>
                             <td className="px-6 py-4 text-kala-300">{artist.country || 'N/A'}</td>
                             <td className="px-6 py-4 text-center text-kala-400">{artist.score}%</td>
                             <td className="px-6 py-4 text-right">
                                <button onClick={() => handleCreateLeadFromMB(artist)} className="bg-green-600 hover:bg-green-500 text-white text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors">
                                   <UserPlus className="w-3 h-3" /> Create Lead
                                </button>
                             </td>
                          </tr>
                       ))}
                    </tbody>
                 </table>
             </div>
           </div>
        )}

        {/* Generated Leads Table */}
        <div className="bg-kala-800/40 border border-kala-700/80 rounded-xl">
            <div className="p-4 border-b border-kala-700">
                <h3 className="font-bold text-white">Generated Leads</h3>
            </div>
            <div className="overflow-x-auto">
               {leads.length > 0 ? (
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-kala-400 uppercase bg-kala-800/60">
                            <tr>
                                <th className="px-6 py-3">Lead Name</th>
                                <th className="px-6 py-3">Assigned To</th>
                                <th className="px-6 py-3">Reason</th>
                                <th className="px-6 py-3 text-center">Confidence</th>
                                <th className="px-6 py-3 text-center">Status</th>
                                <th className="px-6 py-3 text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {leads.map(lead => (
                                <tr key={lead.leadId} className="border-b border-kala-800 hover:bg-kala-800/50">
                                    <td className="px-6 py-4 font-medium text-white">{lead.targetName}</td>
                                    <td className="px-6 py-4 text-kala-300">
                                       {lead.assignedUser ? (
                                           <span className="flex items-center gap-2 text-green-400">
                                              <UserCheck className="w-4 h-4"/>
                                              {users.find(u => u.id === lead.assignedUser)?.name || '-'}
                                           </span>
                                       ) : (
                                           <span className="text-kala-500 italic">Unassigned</span>
                                       )}
                                    </td>
                                    <td className="px-6 py-4 text-kala-400 text-xs">{lead.reason}</td>
                                    <td className="px-6 py-4 text-center">
                                        <span className={`px-2 py-1 rounded-full text-xs font-bold border ${lead.targetId.startsWith('mbid-') ? 'bg-cyan-500/10 text-cyan-300 border-cyan-500/20' : 'bg-green-500/10 text-green-300 border-green-500/20'}`}>
                                            {(lead.confidenceScore * 100).toFixed(0)}%
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-center">
                                       <span className="px-2 py-1 rounded-full text-xs font-bold bg-sky-500/10 text-sky-300 border border-sky-500/20">
                                            {lead.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                       <button onClick={() => handleDeleteLead(lead.leadId)} className="p-1.5 text-kala-500 hover:text-red-500 hover:bg-kala-700 rounded-md transition-colors">
                                          <Trash2 className="w-4 h-4" />
                                       </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
               ) : (
                <div className="text-center py-12 text-kala-500">
                    <p>No leads generated yet.</p>
                    <p className="text-xs">Run a query or search MusicBrainz to find new opportunities.</p>
                </div>
               )}
            </div>
        </div>
      </div>
  );
};

export default AdminLeads;
