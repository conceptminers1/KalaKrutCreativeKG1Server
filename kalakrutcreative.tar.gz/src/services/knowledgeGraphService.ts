
import { Artist, Member, Release, Track, Venue, Event, Sponsor, Nft, MarketplaceListing, PerformedAt, Wrote, Released, CollaboratedWith, Sponsored, HostedAt, HasMember, Produced, AssociatedWith } from '../data/knowledgeGraphSchema';
import { MOCK_PROPOSALS, MOCK_ROSTER } from '../mockData';

class KnowledgeGraph {
  private nodes: {
    artists: Map<string, Artist>;
    members: Map<string, Member>;
    releases: Map<string, Release>;
    tracks: Map<string, Track>;
    venues: Map<string, Venue>;
    events: Map<string, Event>;
    sponsors: Map<string, Sponsor>;
    nfts: Map<string, Nft>;
    marketplaceListings: Map<string, MarketplaceListing>;
    proposals: any;
    [key: string]: Map<string, any>;
  } = {
    artists: new Map(),
    members: new Map(),
    releases: new Map(),
    tracks: new Map(),
    venues: new Map(),
    events: new Map(),
    sponsors: new Map(),
    nfts: new Map(),
    marketplaceListings: new Map(),
    proposals: new Map()
  };

  private edges: {
    performedAt: PerformedAt[];
    wrote: Wrote[];
    released: Released[];
    collaboratedWith: CollaboratedWith[];
    sponsored: Sponsored[];
    hostedAt: HostedAt[];
    hasMember: HasMember[];
    produced: Produced[];
    associatedWith: AssociatedWith[];
  } = {
    performedAt: [],
    wrote: [],
    released: [],
    collaboratedWith: [],
    sponsored: [],
    hostedAt: [],
    hasMember: [],
    produced: [],
    associatedWith: []
  };

  constructor() {
    this.seedInitialData();
  }

  private seedInitialData() {
    const artist1: Artist = { id: 'artist-1', name: 'Luna Eclipse', bio: 'Electronic music producer & DJ', type: 'person' };
    const artist2: Artist = { id: 'artist-2', name: 'Solaris', bio: 'Ambient soundscapes artist', type: 'person' };
    this.addNode('artists', artist1.id, artist1);
    this.addNode('artists', artist2.id, artist2);

    MOCK_PROPOSALS.forEach(p => {
        this.addNode('proposals', p.id, p)
    });
    
    MOCK_ROSTER.forEach(member => {
      this.addNode(member.role.toLowerCase() + 's', member.id, {
          id: member.id,
          name: member.name,
          role: member.role,
          location: member.location,
          verified: member.verified
      });
    });
  }

  public addNode(type: string, id: string, data: any) {
    if (!this.nodes[type]) {
      this.nodes[type] = new Map<string, any>();
    }
    this.nodes[type].set(id, data);
  }

  public getNode<T>(type: keyof typeof this.nodes, id: string): T | undefined {
    const collection = this.nodes[type] as Map<string, T>;
    return collection.get(id);
  }

  public getAllNodes<T>(type: keyof typeof this.nodes): T[] {
    const collection = this.nodes[type] as Map<string, T>;
    return Array.from(collection.values());
  }

  public addEdge<T>(type: keyof typeof this.edges, edge: T) {
    const collection = this.edges[type] as T[];
    collection.push(edge);
  }
  
  public findLeads(query: string): any[] {
     const leads: any[] = [];
     const allArtists = this.getAllNodes('artists');

     if (query.toLowerCase().includes('releases') && query.toLowerCase().includes('no upcoming events')) {
        allArtists.forEach(artist => {
            if (Math.random() > 0.5) { 
                leads.push({
                    leadId: `lead-${artist.id}`,
                    targetId: artist.id,
                    targetName: artist.name,
                    targetType: 'Artist',
                    reason: 'Has recent releases but no scheduled events.',
                    status: 'New',
                    confidenceScore: Math.random() * (0.9 - 0.7) + 0.7,
                });
            }
        });
     }
     return leads;
  }

  public getRosterMembers() {
    return MOCK_ROSTER;
  }
}

export const knowledgeGraph = new KnowledgeGraph();

interface MusicBrainzApiResponse {
  artists: {
    id: string;
    name: string;
    country: string;
    score: number;
  }[];
}

export const searchMusicBrainz = async (query: string): Promise<{ id: string; name: string; country: string; score: number; }[]> => {
  const url = `https://musicbrainz.org/ws/2/artist/?query=${encodeURIComponent(query)}&fmt=json`;

  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'User-Agent': 'KalaKrutApp/1.0.0 ( contact@kalakrut.com )',
      'Accept': 'application/json'
    }
  });

  if (!response.ok) {
    throw new Error(`MusicBrainz API returned status ${response.status}`);
  }

  const data: MusicBrainzApiResponse = await response.json();
  
  return data.artists.map(artist => ({
    id: artist.id,
    name: artist.name,
    country: artist.country,
    score: artist.score,
  }));
};
