# Proposal and Contract Visibility Logic

This document outlines how different types of proposals and contracts are managed and viewed by various user roles within the KalaKrut platform.

## 1. DAO Governance Proposals

*   **Visibility**: DAO proposals are public and visible to all users with governance rights, which include `Admin`, `DAO_Governor`, and `DAO_MEMBER`. The `DaoGovernance.tsx` component is responsible for fetching and displaying a comprehensive list of all active and past proposals.
*   **Identification**: There is no separate "My Proposals" section. Instead, all proposals are displayed in a unified list. The `creator` field on each proposal object identifies the user who initiated it, allowing users to track their own proposals within the main list.
*   **Interaction**: All governance members are encouraged to participate by voting. However, special administrative actions, such as "Veto" or "Force Pass," are restricted based on user roles (`Admin`, `DAO_Governor`) directly within the UI components.

## 2. Business Contracts (Collaboration & Booking Proposals)

*   **Visibility**: Unlike public DAO proposals, business-related contracts are private and confidential. They are managed within the "Proposals & Bookings" hub.
*   **Logic**: The visibility is strictly limited to the parties involved. A user can only view collaboration proposals that they have either **sent** or **received**. They do not have access to business agreements made between other platform members.

## 3. Blockchain Contracts

*   **Visibility**: Blockchain contracts are not standalone, viewable items. They function as technical attachments, linked as `contractData` to either a DAO Governance Proposal or a Business Contract.
*   **Purpose**: These smart contracts are designed to transparently and automatically enforce the terms of an agreement. A common use case is the automatic release of funds from an escrow when predefined milestones are met and verified.
*   **Interaction**:
    *   **General Users**: Interact with the effects of the blockchain contract indirectly. They view its terms and details within the context of the parent proposal they are voting on (for DAO governance) or negotiating (for business collaborations).
    *   **Admins & Governors**: A dedicated `AdminContracts.tsx` component allows for high-level management, review, and deployment of these smart contracts.

---

This tiered visibility model ensures a balance between public governance transparency and private business confidentiality. All interactions are governed by the user's role and their direct involvement in an agreement.
